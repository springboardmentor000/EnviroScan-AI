import pandas as pd
import os

# ==============================
# THRESHOLD CONFIGURATION
# ==============================

HIGH_NO2 = 0.6
HIGH_SO2 = 0.6
HIGH_PM = 0.6

ROAD_THRESHOLD = 2000
INDUSTRY_THRESHOLD = 4000
FARMLAND_THRESHOLD = 6000


# ==============================
# SOURCE LABELING FUNCTION
# ==============================

def assign_source(row):

    # Vehicular pollution
    if row["nearest_road_distance"] < ROAD_THRESHOLD and row["no2"] > HIGH_NO2:
        return "Vehicular"

    # Industrial pollution
    elif row["nearest_industry_distance"] < INDUSTRY_THRESHOLD and row["so2"] > HIGH_SO2:
        return "Industrial"

    # Agricultural pollution
    elif (
        row["nearest_farmland_distance"] < FARMLAND_THRESHOLD
        and row["season"] == "Summer"
        and row["pm2_5"] > HIGH_PM
    ):
        return "Agricultural"

    # Biomass / burning pollution
    elif row["pm2_5"] > 0.8 and row["wind_speed"] < 0.3:
        return "Burning"

    # Natural background pollution
    else:
        return "Natural"


# ==============================
# MODULE 3 MAIN FUNCTION
# ==============================

def run_module3():

    input_path = "data/processed/processed_data.csv"
    output_path = "data/processed/labeled_data.csv"

    df = pd.read_csv(input_path)

    # Apply labeling logic
    df["pollution_source"] = df.apply(assign_source, axis=1)

    # Show label distribution
    print("\n📊 Pollution Source Distribution:")
    print(df["pollution_source"].value_counts())

    # Save labeled dataset
    os.makedirs("data/processed", exist_ok=True)
    df.to_csv(output_path, index=False)

    print("\n✅ Module 3 Completed Successfully!")