from module1.owm_collector import fetch_pollution_weather
from module1.osm_features import fetch_osm_features


def merge_data(lat, lon):

    df = fetch_pollution_weather(lat, lon)
    osm_data = fetch_osm_features(lat, lon)

    for key, value in osm_data.items():
        df[key] = value

    return df