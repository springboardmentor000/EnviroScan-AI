import pandas as pd
import os
import osmnx as ox
import geopandas as gpd
from shapely.geometry import Point
from sklearn.preprocessing import MinMaxScaler
from config import LAT, LON, RADIUS


def run_module2():

    input_path = "data/raw/single_location_data.csv"
    output_path = "data/processed/processed_data.csv"

    # =====================================================
    # 1️⃣ LOAD RAW DATA
    # =====================================================
    df = pd.read_csv(input_path)
    print("Initial shape:", df.shape)

    # =====================================================
    # 2️⃣ REMOVE INVALID POLLUTION VALUES
    # =====================================================
    pollution_cols = ["pm2_5","pm10","no2","co","so2","o3"]

    for col in pollution_cols:
        df = df[df[col] >= 0]

    # =====================================================
    # 3️⃣ REMOVE DUPLICATES (BASED ON POLLUTION + WEATHER)
    # =====================================================
    print("Before removing duplicates:", df.shape)

    duplicates = df.duplicated(subset=[
        "pm2_5","pm10","no2","co","so2","o3",
        "temperature","humidity","wind_speed"
    ]).sum()

    print("Duplicate rows found:", duplicates)

    df = df.drop_duplicates(subset=[
        "pm2_5","pm10","no2","co","so2","o3",
        "temperature","humidity","wind_speed"
    ])

    print("After removing duplicates:", df.shape)

    # =====================================================
    # 4️⃣ HANDLE MISSING VALUES
    # =====================================================
    df = df.infer_objects(copy=False)
    df = df.interpolate(method="linear", numeric_only=True)
    df = df.fillna(df.mean(numeric_only=True))

    # =====================================================
    # 5️⃣ STANDARDIZE TIMESTAMP
    # =====================================================
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")

    # =====================================================
    # 6️⃣ TEMPORAL FEATURES
    # =====================================================
    df["hour"] = df["timestamp"].dt.hour
    df["day_of_week"] = df["timestamp"].dt.dayofweek
    df["month"] = df["timestamp"].dt.month

    def get_season(month):
        if month in [12,1,2]:
            return "Winter"
        elif month in [3,4,5]:
            return "Summer"
        elif month in [6,7,8,9]:
            return "Monsoon"
        else:
            return "Post-Monsoon"

    df["season"] = df["month"].apply(get_season)

    # =====================================================
    # 7️⃣ POLLUTION LEVEL CLASSIFICATION
    # =====================================================
    def pollution_level(pm):
        if pm <= 30:
            return "Low"
        elif pm <= 60:
            return "Moderate"
        elif pm <= 90:
            return "High"
        else:
            return "Severe"

    df["pollution_level"] = df["pm2_5"].apply(pollution_level)

    # =====================================================
    # 8️⃣ DISTANCE FEATURES (METERS)
    # =====================================================
    center = (LAT, LON)
    point = Point(LON, LAT)

    # Road network
    G = ox.graph_from_point(center, dist=RADIUS, network_type="drive")
    nodes, edges = ox.graph_to_gdfs(G)

    edges_proj = edges.to_crs(epsg=3857)
    point_proj = gpd.GeoSeries([point], crs="EPSG:4326").to_crs(epsg=3857).iloc[0]

    edges_proj["dist"] = edges_proj.geometry.distance(point_proj)
    nearest_road_distance = edges_proj["dist"].min()

    # Industrial areas
    industrial = ox.features_from_point(
        center,
        tags={"landuse": "industrial"},
        dist=RADIUS
    )

    if not industrial.empty:
        industrial_proj = industrial.to_crs(epsg=3857)
        industrial_proj["dist"] = industrial_proj.geometry.distance(point_proj)
        nearest_industry_distance = industrial_proj["dist"].min()
    else:
        nearest_industry_distance = None

    # Farmland / Agricultural
    farmland = ox.features_from_point(
        center,
        tags={"landuse": "farmland"},
        dist=RADIUS
    )

    if not farmland.empty:
        farmland_proj = farmland.to_crs(epsg=3857)
        farmland_proj["dist"] = farmland_proj.geometry.distance(point_proj)
        nearest_farmland_distance = farmland_proj["dist"].min()
    else:
        nearest_farmland_distance = None

    df["nearest_road_distance"] = nearest_road_distance
    df["nearest_industry_distance"] = nearest_industry_distance
    df["nearest_farmland_distance"] = nearest_farmland_distance

    # =====================================================
    # 9️⃣ NORMALIZATION (EXCLUDING DISTANCE)
    # =====================================================
    scaler = MinMaxScaler()

    numeric_cols = [
        "pm2_5","pm10","no2","co","so2","o3",
        "temperature","humidity","wind_speed"
    ]

    df[numeric_cols] = scaler.fit_transform(df[numeric_cols])

    # =====================================================
    # 🔟 SAVE PROCESSED DATA
    # =====================================================
    os.makedirs("data/processed", exist_ok=True)
    df.to_csv(output_path, index=False)

    print("Final shape:", df.shape)
    print("✅ Module 2 Completed Successfully!")