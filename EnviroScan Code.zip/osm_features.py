# module1/osm_features.py

import osmnx as ox
from config import LAT, LON, RADIUS


def get_osm_features():
    try:
        center_point = (LAT, LON)

        # -------- ROAD NETWORK (Correct Method) --------
        try:
            G = ox.graph_from_point(center_point, dist=RADIUS, network_type="drive")
            road_count = len(list(G.edges))
        except:
            road_count = 0

        # -------- INDUSTRIAL --------
        try:
            industrial = ox.features_from_point(
                center_point,
                tags={"landuse": "industrial"},
                dist=RADIUS
            )
            industrial_count = len(industrial)
        except:
            industrial_count = 0

        # -------- FARMLAND --------
        try:
            farmland = ox.features_from_point(
                center_point,
                tags={"landuse": "farmland"},
                dist=RADIUS
            )
            farmland_count = len(farmland)
        except:
            farmland_count = 0

        return road_count, industrial_count, farmland_count

    except Exception as e:
        print("OSM Major Error:", e)
        return 0, 0, 0