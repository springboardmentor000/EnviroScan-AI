import os
from config import LAT, LON, CITY_NAME, CSV_FILE
from module1.owm_collector import fetch_pollution_weather
from module1.osm_features import get_osm_features
from module2.data_processing import run_module2
from module3.source_labeling import run_module3


def main():

    # =========================
    # MODULE 1: DATA COLLECTION
    # =========================
    df_pollution = fetch_pollution_weather(LAT, LON)

    if df_pollution is None:
        print("❌ Failed to fetch pollution/weather data.")
        return

    road_count, industrial_count, farmland_count = get_osm_features()

    df_pollution["city"] = CITY_NAME
    df_pollution["road_count"] = road_count
    df_pollution["industrial_count"] = industrial_count
    df_pollution["farmland_count"] = farmland_count

    if not os.path.isfile(CSV_FILE):
        df_pollution.to_csv(CSV_FILE, index=False)
    else:
        df_pollution.to_csv(CSV_FILE, mode="a", header=False, index=False)

    print("✅ Module 1 Completed")

    # =========================
    # MODULE 2: CLEANING
    # =========================
    run_module2()

    # =========================
    # MODULE 3: LABELING
    # =========================
    run_module3()

    print("🚀 Full Pipeline Executed Successfully!")


if __name__ == "__main__":
    main()