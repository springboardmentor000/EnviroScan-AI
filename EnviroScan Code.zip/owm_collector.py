import requests
import pandas as pd
from datetime import datetime
from config import OWM_API_KEY


def fetch_pollution_weather(lat, lon):
    try:
        pollution_url = f"https://api.openweathermap.org/data/2.5/air_pollution?lat={lat}&lon={lon}&appid={OWM_API_KEY}"
        weather_url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={OWM_API_KEY}&units=metric"

        pollution_response = requests.get(pollution_url).json()
        weather_response = requests.get(weather_url).json()

        # DEBUG: print actual response if list not found
        if "list" not in pollution_response:
            print("❌ Pollution API Full Response:", pollution_response)
            return None

        pollution_data = pollution_response["list"][0]["components"]

        data = {
            "timestamp": datetime.now(),
            "latitude": lat,
            "longitude": lon,
            "pm2_5": pollution_data.get("pm2_5"),
            "pm10": pollution_data.get("pm10"),
            "no2": pollution_data.get("no2"),
            "co": pollution_data.get("co"),
            "so2": pollution_data.get("so2"),
            "o3": pollution_data.get("o3"),
            "temperature": weather_response["main"]["temp"],
            "humidity": weather_response["main"]["humidity"],
            "wind_speed": weather_response["wind"]["speed"],
            "wind_deg": weather_response["wind"].get("deg", 0),
        }

        return pd.DataFrame([data])

    except Exception as e:
        print("OWM Error:", e)
        return None